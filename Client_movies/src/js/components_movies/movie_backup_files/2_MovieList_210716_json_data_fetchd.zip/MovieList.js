var React = require('react');
var ReactDOM = require('react-dom');
var Movie =require('./Movie');

var MovieList = React.createClass({
  render: function () {
    return (
      <div className="movieList">
      <h2> Movie List </h2>

		<Movie />
      </div>
    );
  }
});

module.exports = MovieList;