var React = require('react');
var ReactDOM = require('react-dom');



var MovieForm = React.createClass({

  getInitialState: function() {
    return{Title:""}
  },
  handleTitleChange:function(e){
    this.setState({Title:e.target.value});
    console.log(this.state.Title);
  },
  submitTitle: function(e){
    e.preventDefault();
    {
      this.props.handlesubmitTitle({Title:this.state.Title});
    }
  },
  render: function () {
    return (
      <div className="movieForm">

          <div class="container-fluid">
            <div class="row">
              <div class="col-md-12">
                <h2> Movie Form </h2>
                  <form onSubmit={this.submitTitle} className="movieForm">
                    <input
                      type="text"
                      name="Title"
                      placeholder="Movie Name"
                      value={this.state.Title}
                      onChange={this.handleTitleChange}                        ]
                      />
                    <input type="submit" value="Search" />
                  </form>


              </div>
            </div>
          </div>      


      </div>
    );
  }
});

module.exports = MovieForm;