var React = require('react');
var ReactDOM = require('react-dom');


var Movie = React.createClass({

  
  render: function () {
    return (
      <div className="movie">
      <h4 className="movieName">
      <div className="container-fluid">
			<div className="row">
				<div className="col-md-6">
					<img alt="Bootstrap Image Preview" src={this.props.allMovies.Poster}/>
				</div>
				<div className="col-md-6" >
				{this.props.allMovies.Title}
				</div>
			</div>
		</div>

       </h4>
      </div>
    );
  }
});

module.exports = Movie;
